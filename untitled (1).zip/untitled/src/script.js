let count = 0;
const likeBtn = document.getElementById('likeBtn');
const likeCount = document.getElementById('likeCount');

likeBtn.addEventListener('click', () => {
  count++;
  likeCount.textContent = count;
});
